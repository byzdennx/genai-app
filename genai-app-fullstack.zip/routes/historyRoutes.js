const express = require("express");
const router = express.Router();
const History = require("../models/History");
const auth = require("../middleware/authMiddleware");

router.get("/", auth, async (req, res) => {
  const history = await History.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json(history);
});

router.delete("/", auth, async (req, res) => {
  await History.deleteMany({ userId: req.user.id });
  res.json({ message: "History cleared" });
});

module.exports = router;
